#include<stdio.h>
#include<stdlib.h>

FILE *file1;
FILE *file2;
struct node{
    char word[10];
    char meaning[20];
    struct node *left;
    struct node *right;
}*root = NULL, *tail, *newnode, *temp, *temp1;

void create(){
    int flag = 0;

    file1 = fopen("word.txt","a+");
    file2 = fopen("meaning.txt","a+");
    while((!feof(file1))&&(!feof(file2))){
        newnode = (struct node*)malloc(sizeof(struct node));
        fgets(newnode ->word,10,file1);
        fgets(newnode -> meaning,20,file2);


        newnode -> left = NULL;
        newnode -> right = NULL;
        temp1 =root;

    if(root == NULL){
        root = newnode;
    }

    else{
         while(temp1!= NULL){
            if(compare(newnode -> word,temp1->word) > 0){
                    temp = temp1;
                    temp1 = temp1-> right;
            }

            else if(compare(newnode -> word,temp1->word) < 0){
                    temp = temp1;
                    temp1 = temp1-> left;
            }
        }
        if(flag==0 && temp1==NULL){
         if(compare(temp->word,newnode->word)==1){
            temp->left=newnode;
        }
         else if(compare(temp->word,newnode->word)==-1){
            temp->right=newnode;
                }
            }

        }
    }
    fclose(file1);
    fclose(file2);

}


void insert(){
    file1 = fopen("word.txt","a+");
    file2 = fopen("meaning.txt","a+");
    int flag = 0;

    newnode = (struct node*)malloc(sizeof(struct node));
    printf("Enter the word: \n");
    scanf("%s", &newnode ->word);
    fputs(newnode ->word,file1);
    printf("Enter the meaning: \n");
    scanf("%s", &newnode -> meaning);
    fputs(newnode ->meaning,file2);
    newnode -> left = NULL;
    newnode -> right = NULL;
    temp1 =root;

    if(root == NULL){
        root = newnode;
    }

    else{
         while(temp1!= NULL){
            if(compare(newnode -> word,temp1->word) == 0){
                printf("The word already exist");
                flag = 1;
                break;
            }

            else if(compare(newnode -> word,temp1->word) > 0){
                    temp = temp1;
                    temp1 = temp1-> right;
            }

            else if(compare(newnode -> word,temp1->word) < 0){
                    temp = temp1;
                    temp1 = temp1-> left;
            }
        }
        if(flag==0 && temp1==NULL){
         if(compare(temp->word,newnode->word)==1){
            temp->left=newnode;
        }
         else if(compare(temp->word,newnode->word)==-1){
            temp->right=newnode;
         }
       }
       fprintf(file1,"\n%s",newnode->word);
       fprintf(file2,"\n%s",newnode->meaning);

    }
    fclose(file1);
    fclose(file2);
}


void search(){
    char arr[10];
    int flag = 0;
    temp = root;
    printf("Enter the word: \n");
    scanf("%s",arr);

    if(root == NULL){
        printf("The dictionary is empty");
    }

    else{
        while(temp!= NULL && flag == 0){
            if(compare(arr,temp->word) == 0){
                printf("The meaning is %s",temp->meaning);
                flag = 1;
            }

        else if(compare(arr,temp->word)> 0){
                temp = temp-> right;
        }

        else if(compare(arr,temp->word)< 0){
                temp = temp-> left;
        }
    }
}

    if(flag == 0){
        printf("\nThe word %s was not found\n Similar words: ",arr);
        similar(arr);
    }
}


int compare(char a[], char b[]){
    int m,n,p;
    for(m=0,n=0; a[m]!='\0' && b[n]!='\0'; m++,n++){
        if(a[m] > b[n]){
            p=1;
            break;
        }
        else if(a[m] < b[n]){
            p=-1;
            break;
        }
        else{
            p = 0;
        }
    }
    if(p==0){
        return 0;
    }

    else if(p==1){
        return 1;
    }

    else if(p==-1){
        return -1;
    }
}

int compare2(char a[], char b[]){
    int m,n,p=0,q,flag=0;
    for(m=0,n=0; a[m]!='\0' && b[n]!='\0'; m++,n++){
        if(a[m] > b[n]){
            p=1;
        }
        else if(a[m] < b[n]){
            p=-1;
        }
            p++;
    }
    p = strlen(a);
    q = strlen(b);
    if(p<q){
        p=p/2;
    }
    else{
        p=q/2;
    }

    for(m=0,n=0; m<=p && n<=p; m++,n++){
            if(a[m] != b[n]){
                flag= 1;
            }
    }
    if(flag == 0){
        printf("%s \n",b);
    }

    if(p==1){
        return 1;
    }

    else if(p==-1){
        return 2;
    }
}

void delet_search(){
    char arr[10];
    int flag = 0;
    temp = root;
    printf("Enter the word: \n");
    scanf("%s",arr);

    if(root == NULL){
        printf("The dictionary is empty");
    }

    else{
         while(temp!= NULL && flag == 0){
            if(compare(arr,temp->word) == 0){
                delet(temp);
                printf("\n%s has been deleted\n",temp->word);
                flag = 1;
                break;
            }

            else if(compare(arr,temp->word) == 1){
                    temp = temp-> right;
            }

            else if(compare(arr,temp->word) == 2){
                    temp = temp-> left;
            }
    }

    if(flag = 0){
        printf("The word %s was not found",arr);
        }
    }
}

void delet(struct node *temp, char arr[]){

        if(temp->left == NULL && temp->right == NULL){
            printf("\n%s has been deleted\n",temp->word);
            free(temp);
           // break;

        }
    else if(temp->left == NULL){
            temp1 = temp;
            temp = temp->right;
            printf("\n%s has been deleted\n",temp1->word);
            free(temp1);
           // break;

        }
    else if(temp->right == NULL){
            temp1 = temp;
            temp = temp->left;
            printf("\n%s has been deleted\n",temp1->word);
            free(temp1);
           // break;

        }
    else{
            temp1=minValue(temp);
            temp= temp1;
            printf("%s has been deleted\n",temp1->word);
            free(temp1);
           // break;
        }
}

int minValue(struct node* temp){
        temp1=temp->right;
        while(temp1->left!= NULL){
            temp1=temp1->left;
        }
        return (temp1->left);
}

void similar(char arr[]){
    temp = root;
    while(temp!= NULL){
        if(compare2(arr,temp->word) > 0){
                temp = temp-> right;
        }

        else if(compare2(arr,temp->word) < 0){
                temp = temp-> left;
        }
    }
}

int main(){
    create();
    int i, n, x;
        while(1){
        printf("Please insert your option:\n");
        printf(" 1.new word\n 2.search word\n 3.delete\n 4.Exit your code\n");
        printf("Enter your option: ");
        scanf("%d",&n);

        if(n == 1){
            printf("Enter how many new words to input: ");
            scanf("%d",&x);
            for(i = 0; i < x; i++){
            insert();
            printf("\n");
            }
        }

        else if(n == 2){
            search();
            printf("\n");
        }

        else if(n == 3){
            delet_search();
            printf("\n");
        }

        else if(n == 4){
            break;
        }

        else{
            printf("\nYour Input is wrong, please choice between 1-4\n");
        }
    }
    return 0;
}



